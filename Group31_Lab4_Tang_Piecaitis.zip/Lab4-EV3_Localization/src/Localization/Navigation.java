
package Localization;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

/*
 * This class contains methods to navigate to specific points on the cartesian map or turn to angles.
 * First tile is at the left bottom. First tile's top right corner is (0.0).
 * 0 degree is positive y axis.
 */
public class Navigation {

	//initializations
	public static final double WHEEL_RADIUS = 2.15;
	public static final double TRACK = 16.2; 
	private static final int ROTATE_SPEED = 150;
	double rTheta, dTheta, turnTheta, rX, rY, distance, error;
	private Odometer odometer;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;

	public Navigation(Odometer odo, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor ) {
		this.odometer = odo;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;

		// reset the motors
		leftMotor.setSpeed(0);
		rightMotor.setSpeed(0);
		leftMotor.setAcceleration(1000);
		rightMotor.setAcceleration(1000);
	}


	//Functions to set the motor speeds jointly
	public void setSpeeds(float lSpd, float rSpd) {
		this.leftMotor.setSpeed(lSpd);
		this.rightMotor.setSpeed(rSpd);
		if (lSpd < 0)
			this.leftMotor.backward();
		else
			this.leftMotor.forward();
		if (rSpd < 0)
			this.rightMotor.backward();
		else
			this.rightMotor.forward();
	}


	//Float the two motors jointly
	public void setFloat() {
		this.leftMotor.stop();
		this.rightMotor.stop();
		this.leftMotor.flt(true);
		this.rightMotor.flt(true);
	}

	
	/*
	 * This method will make the robot travel to a specific point on the cartesian coordinates.
	 * It calls another method to execute turns.
	 */
	void travelTo (double dx, double dy){ 			//dx and dy are desired position
			
			rX = odometer.getX();					//get robot's current position
			rY = odometer.getY();
			distance = Math.sqrt(Math.pow((dx-rX), 2) + Math.pow((dy-rY), 2)); //distance to be traveled
					
			//calculate desired angle orientation (dTheta)
			if ((dx-rX) > 0){ 
				dTheta = (Math.atan2(dx-rX, dy-rY))*180/3.1415926;
			}
			else if(dy-rY > 0){
				dTheta =( Math.atan2(dx-rX, dy-rY) ) *180/3.1415926;
			}
			else {
				dTheta = 180- (Math.atan2(dx-rX, dy-rY))*180/3.1415926;
			}
			
			//perform rotation toward destination point
			turnTo (dTheta, leftMotor, rightMotor, WHEEL_RADIUS, WHEEL_RADIUS, TRACK);
			
			//travel forward 
			forward(distance);
	}

	/*
	 * This method executes rotates the robot to a specific point indicated by the previous method travelTo
	 */
	void turnTo (double dTheta,  EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
		double leftRadius, double rightRadius, double width){
		
		
		double rTheta = odometer.getTheta();	//record current heading
		error = dTheta - rTheta;		//error is amount of angle desired to turn
			
			//calculate minimum angle for turns
			if (error < -180){
				turnTheta = 360 + error;
			}
			else if (error > 180) {
				turnTheta = error - 360;
			}
			else {
				turnTheta = error; 
			}
			
			//set speeds and execute turns 
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);
	
			leftMotor.rotate(convertAngle(leftRadius, width, turnTheta), true);
			rightMotor.rotate(-convertAngle(rightRadius, width, turnTheta), false);
			
	}
	

	
	//This method makes robot move forward a specific distance d
	void forward(double d){
		leftMotor.setSpeed(125);
		rightMotor.setSpeed(125);

		leftMotor.rotate(convertDistance( WHEEL_RADIUS, d), true); 
		rightMotor.rotate(convertDistance( WHEEL_RADIUS, d), false);
	}
	
	//This method makes robot move backwards a specific distance d
	void backward (double d){
		leftMotor.setSpeed(125);
		rightMotor.setSpeed(125);

		leftMotor.rotate(-convertDistance( WHEEL_RADIUS, d), true); 
		rightMotor.rotate(-convertDistance( WHEEL_RADIUS, d), false);
}
	//This method makes robot rotate specific angle deg
	void rotate(int deg){
		leftMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, deg), true);
		rightMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, deg), false);
	}
	
	//This method converts a certain distance to number to radians the wheels should turn
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	//This method converts the angle of orientation of the robot from degrees to number of radians wheels should rotate
	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	
}
