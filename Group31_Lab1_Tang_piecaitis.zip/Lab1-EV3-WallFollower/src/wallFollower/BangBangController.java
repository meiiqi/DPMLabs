package wallFollower;
import lejos.hardware.motor.*;

public class BangBangController implements UltrasonicController{
	private final int bandCenter, bandwidth;
	private final int motorLow, motorHigh;
	private int distance;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	private int filterControl;
	private final int FILTER_OUT = 20;
	
	public BangBangController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
							  int bandCenter, int bandwidth, int motorLow, int motorHigh) {
		//Default Constructor
		this.bandCenter = bandCenter;
		this.bandwidth = bandwidth;
		this.motorLow = motorLow;
		this.motorHigh = motorHigh;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		leftMotor.setSpeed(motorHigh);				// Start robot moving forward
		rightMotor.setSpeed(motorHigh);
		leftMotor.forward();
		rightMotor.forward();
	}
	
	@Override
	public void processUSData(int distance) {
		this.distance = distance;
		
		if (distance >= 255 && filterControl < FILTER_OUT) {
			// bad value, do not set the distance variable, however do increment the
			// filter value
			filterControl++;
		} else if (distance >= 255) {
			// We have repeated large values, so there must actually be nothing
			// there: leave the distance alone
			this.distance = distance;
		} else {
			// distance went below 255: reset filter and leave
			// distance alone.
			filterControl = 0;
			this.distance = distance;
		}
		
		
		// process a movement based on the us distance passed in (BANG-BANG style)
		int deltaError = distance - bandCenter; 		//positive deltaError = far from wall
		
		
		
		if ((Math.abs(deltaError) <= bandwidth)) {		//Don't adjust if deltaError is within threshold
			leftMotor.setSpeed(motorHigh);				// robot moves forward
			rightMotor.setSpeed(motorHigh);
			leftMotor.forward();
			rightMotor.forward();
		}
		
		
		else if (deltaError < 0 ) {    					//Robot is too close to wall, need right turn
			
			if (distance <20){
				leftMotor.setSpeed(200);				// reverse right wheel to help turn right more efficiently
				rightMotor.setSpeed(400);				
				leftMotor.forward();
				rightMotor.backward();
			} 
			
			else {
				leftMotor.setSpeed(2*motorHigh);		// Scalar helps make bigger right turn  
				rightMotor.setSpeed(motorLow);			
				leftMotor.forward();
				rightMotor.forward();
			}
			
		}
		
		else if (deltaError > 0 && distance < 255 ) { 	//Robot is too far from wall, need left turn
			
			if (distance > 45) {
				leftMotor.setSpeed(motorLow);			
				rightMotor.setSpeed((int) (1.5*motorHigh));		//Scalar helps make bigger left turn
				leftMotor.forward();
				rightMotor.forward();
			} 
			
			else {
				leftMotor.setSpeed(motorLow);					
				rightMotor.setSpeed(motorHigh);		//slightly smaller left turn if not that far ( < 45 from wall)
				leftMotor.forward();
				rightMotor.forward();
			}
		}
		
		else if (distance >= 255){						// If at the end of blocks, need to U-turn
			leftMotor.setSpeed(motorLow+55);			//turn left
			rightMotor.setSpeed(motorHigh);				
			leftMotor.forward();
			rightMotor.forward();
		}
	}

	@Override
	public int readUSDistance() {
		return this.distance;
	}
}
