package Navigation;

import lejos.hardware.motor.EV3LargeRegulatedMotor;
import java.lang.Math;


/*
 * This thread implements a simple navigation that also avoids obstacles 
 * somewhere on its path with the help of the Ultrasonic sensor.
 * Unfortunately, we were not able to figure out the implementation for bangbang wallfollower with this navigation in time,
 * although it would be a much more efficient method of avoiding obstacles.
 */
public class NavigationPart2 extends Thread implements UltrasonicController{

	//initializations
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	private static final double tooClose = 23;
	public static final double WHEEL_RADIUS = 2.15;
	public static final double TRACK = 16.2; 
	private static final int FORWARD_SPEED = 250;
	private static final int ROTATE_SPEED = 150;
	double rTheta, dTheta, turnTheta, rX, rY, distance, error;
	public boolean travelingState, blockPassed;
	private int sensorDist;
	
	private Odometer odometer;
	
	//constructor
	public NavigationPart2 (Odometer odometer, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor) {
		this.odometer = odometer;
		this.leftMotor = leftMotor;
		this.rightMotor= rightMotor;	
	}


	//Thread starts here
		public void run(){
			int i=0; 
			travelingState = true;
			blockPassed = false;
			leftMotor.setSpeed(0);
			rightMotor.setSpeed(0);
			leftMotor.setAcceleration(500);
			rightMotor.setAcceleration(500);
			
			
			//executes travelTo methods, pauses when going aroung obstacle
			//loop makes it resume afterwards
			while(true){
				
				while(isNavigating() == true){ 
					
					//if at second part of path
					if(odometer.getX()>5){ //assumes still on first part of path if within 5cm of threshold
						travelTo(60,0);
					}
					else{
						travelTo(0,60);
						travelTo(60,0);
					} 
				}
				//wait until navigation resumes
				while(isNavigating()== false);
			}
		}
		
		/*
		 * This method processes data feeding through the UltrasonicPoller
		 * It will contour an obstacle if it is at a distance of 23cm.
		 */
		@Override
		public void processUSData(int sensorDist) {
			this.sensorDist = sensorDist;
			
				if (sensorDist < tooClose&& !blockPassed){
					setNavigatingState(false); 	//stop navigation
					blockPassed = true;  		//indicates already passed block, to stop sensor from continue sensing later on
					
					//stop motors to interrupt thread
					leftMotor.stop(true);
					rightMotor.stop(true);			
					
					for (EV3LargeRegulatedMotor motor : new EV3LargeRegulatedMotor[] { leftMotor, rightMotor }) {
						motor.stop();
						motor.setAcceleration(200);
					}
					
					avoidObstacle();
					
					setNavigatingState(true); //resume navigation
				}
		}

		
		@Override
		public int readUSDistance() {
			return this.sensorDist;
		}
	
	
		/*
		 * This method will make the robot travel to a specific point on the cartesian coordinates.
		 * It calls another method to execute turns.
		 */
		void travelTo (double dx, double dy){						//dx and dy desired position
				setNavigatingState(true);
				rTheta = ((odometer.getTheta())*180/3.1415926);
				rX = odometer.getX();								//odometer's current Theta
				rY = odometer.getY();								//current position
				distance = Math.sqrt(Math.pow((dx-rX), 2) + Math.pow((dy-rY), 2)); //distance to be traveled
						
				if ((dx-rX) > 0){
					dTheta = (Math.atan2(dx-rX, dy-rY))*180/3.1415926;
				}
				else if(dy-rY > 0){
					dTheta =( Math.atan2(dx-rX, dy-rY) ) *180/3.1415926;
				}
				else {
					dTheta = 180- (Math.atan2(dx-rX, dy-rY))*180/3.1415926;
					
				}
				
				turnTo (dTheta, leftMotor, rightMotor, WHEEL_RADIUS, WHEEL_RADIUS, TRACK);
				
				setNavigatingState(false);
		}
	
		/*
		 * This method executes turns and drives the robot to a specific point indicated by the previous method travelTo
		 */
		void turnTo (double dTheta, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
			double leftRadius, double rightRadius, double width){
	
				//amount of angle desired to turn
				error = dTheta - rTheta;
				//calculate minimum angle for turns
				if (error < -180){
					turnTheta = 360 + error;
				}
				else if (error > 180) {
					turnTheta = error - 360;
				}
				else {
					turnTheta = error; 
		
				}
		
				leftMotor.setSpeed(ROTATE_SPEED);
				rightMotor.setSpeed(ROTATE_SPEED);
		
				leftMotor.rotate(convertAngle(leftRadius, width, turnTheta), true);
				rightMotor.rotate(-convertAngle(rightRadius, width, turnTheta), false);
				
				forward(distance);
		
		}
		
		/*
		 * isNavigating() indicates if travelTo or turnTo are called.
		 * Traveling state is false when the robot is avoiding osbtacles
		 */
		public boolean isNavigating(){
			return travelingState;
		}
		
		/*
		 * This methods sets the navigating state.
		 */
		public void setNavigatingState(boolean x){
			travelingState = x;
		}
	
		/*
		 * This method contains the specific commands to avoid an obstacle.
		 * A better implementation should be either the Bangbang or P-Control wall follower
		 * However, we did not get to make it work on time.
		 * This simple implementation is designed to avoid obstacles in the most optimized way.
		 */
		private void avoidObstacle(){
				turnRight();
				forward(27);
				turnLeft();
				forward(57);
				turnLeft();
				forward(27);
				turnRight();
		}
	
		
		//Commands for right turns	
		public void turnRight(){
			
				leftMotor.setSpeed(ROTATE_SPEED);
				rightMotor.setSpeed(ROTATE_SPEED);
			
				leftMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, 90.0), true);
				rightMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, 90.0), false);
		}

		//commands for left turns
		public void turnLeft (){
				leftMotor.setSpeed(ROTATE_SPEED);
				rightMotor.setSpeed(ROTATE_SPEED);
	
				leftMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, 90.0), true);
				rightMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, 90.0), false);
		}
		
		//make robot move forward a specific distance d
		public void forward(double d){
				leftMotor.setSpeed(FORWARD_SPEED);
				rightMotor.setSpeed(FORWARD_SPEED);
	
				leftMotor.rotate(convertDistance( WHEEL_RADIUS, d), true); 
				rightMotor.rotate(convertDistance( WHEEL_RADIUS, d), false);
		}
		
		
		//Convert a certain distance to number to radians the wheels should turn
		private static int convertDistance(double radius, double distance) {
			return (int) ((180.0 * distance) / (Math.PI * radius));
		}
		
		//Convert the angle of orientation of the robot from degrees to number of radians wheels should rotate
		private static int convertAngle(double radius, double width, double angle) {
			return convertDistance(radius, Math.PI * width * angle / 360.0);
		}

}
