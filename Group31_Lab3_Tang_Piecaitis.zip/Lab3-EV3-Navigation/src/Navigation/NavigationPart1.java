package Navigation;

import lejos.hardware.motor.EV3LargeRegulatedMotor;
import java.lang.Math;

/*
 * This thread implements a simple navigation that follows a specific path.
 */
public class NavigationPart1 extends Thread {
	
	//initializations
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	public static final double WHEEL_RADIUS = 2.15;
	public static final double TRACK = 16.2; 
	private static final int FORWARD_SPEED = 250;
	private static final int ROTATE_SPEED = 150;
	double rTheta, dTheta, turnTheta, rX, rY, distance, error;
	//create local instances
	private Odometer odometer;
	
	public NavigationPart1 (Odometer odometer, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor) {
		this.odometer = odometer;
		this.leftMotor = leftMotor;
		this.rightMotor= rightMotor;	
	}
	
	//Thread starts here
	public void run() {
		
		// reset the motors
		leftMotor.setSpeed(0);
		rightMotor.setSpeed(0);
		leftMotor.setAcceleration(1000);
		rightMotor.setAcceleration(1000);
		
		//Execute specific path
		for (int i=0; i<4; i++){
			if (i==0) { travelTo(60,30);}
			else if (i==1){ travelTo(30,30);}
			else if (i==2){ travelTo(30,60);}
			else { travelTo(60,0);}
		}
	}
	

	/*
	 * This method will make the robot travel to a specific point on the cartesian coordinates.
	 * It calls another method to execute turns.
	 */
	void travelTo (double dx, double dy){ 					//dx and dy desired position
			
			rTheta = ((odometer.getTheta())*180/3.1415926); //odometer's current Theta
			rX = odometer.getX();							//current position
			rY = odometer.getY();
			distance = Math.sqrt(Math.pow((dx-rX), 2) + Math.pow((dy-rY), 2)); //distance to be traveled
					
			//calculate desired angle orientation 
			if ((dx-rX) > 0){ 
				dTheta = (Math.atan2(dx-rX, dy-rY))*180/3.1415926;
			}
			else if(dy-rY > 0){
				dTheta =( Math.atan2(dx-rX, dy-rY) ) *180/3.1415926;
			}
			else {
				dTheta = 180- (Math.atan2(dx-rX, dy-rY))*180/3.1415926;
				
			}
			
			turnTo (dTheta, leftMotor, rightMotor, WHEEL_RADIUS, WHEEL_RADIUS, TRACK);
	}

	/*
	 * This method executes turns and drives the robot to a specific point indicated by the previous method travelTo
	 */
	void turnTo (double dTheta, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
		double leftRadius, double rightRadius, double width){
		
			//amount of angle desired to turn
			error = dTheta - rTheta;
			
			//calculate minimum angle for turns
			if (error < -180){
				turnTheta = 360 + error;
			}
			else if (error > 180) {
				turnTheta = error - 360;
			}
			else {
				turnTheta = error; 
			}
			
			//execute turns 
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);
	
			leftMotor.rotate(convertAngle(leftRadius, width, turnTheta), true);
			rightMotor.rotate(-convertAngle(rightRadius, width, turnTheta), false);
			
			forward(distance);
	
	}
	

	
	//make robot move forward a specific distance d
	private void forward(double d){
			leftMotor.setSpeed(FORWARD_SPEED);
			rightMotor.setSpeed(FORWARD_SPEED);

			leftMotor.rotate(convertDistance( WHEEL_RADIUS, d), true); 
			rightMotor.rotate(convertDistance( WHEEL_RADIUS, d), false);
	}
	
	
	//Convert a certain distance to number to radians the wheels should turn
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	//Convert the angle of orientation of the robot from degrees to number of radians wheels should rotate
	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
}
	
