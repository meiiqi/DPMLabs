package Navigation;

public interface UltrasonicController {
	
	public void processUSData(int distance1) ;
	
	public int readUSDistance();
}
