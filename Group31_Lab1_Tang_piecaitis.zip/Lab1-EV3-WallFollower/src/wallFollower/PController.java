package wallFollower;
import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class PController implements UltrasonicController {
	
	private final int motorStraight = 200, FILTER_OUT = 20;
	private int motorAdjust;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	private int distance;
	private int filterControl;
	
	public PController(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor) {
		//Default Constructor
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		leftMotor.setSpeed(motorStraight);		// Start robot moving forward
		rightMotor.setSpeed(motorStraight); 	
		leftMotor.forward();
		rightMotor.forward();
		filterControl = 0;
	}
	
	@Override
	public void processUSData(int distance) {

		// rudimentary filter - toss out invalid samples corresponding to null
		// signal.
		// (n.b. this was not included in the Bang-bang controller, but easily
		// could have).
		//
		
		if (distance >= 255 && filterControl < FILTER_OUT) {
			// bad value, do not set the distance variable, however do increment the
			// filter value
			filterControl++; 
		} else if (distance >= 255) {
			// We have repeated large values, so there must actually be nothing
			// there: leave the distance alone
			this.distance = distance;
			
		} else {
			// distance went below 255: reset filter and leave
			// distance alone.
			filterControl = 0;
			this.distance = distance;
		} 
		
		
		// Process a movement based on the us distance passed in (Proportional control style)
		if (distance > 30  ){							
			
			if (distance > 60){                         //Stabilize the speed for too large distances
				distance = 60; 							
			}
														//only adjust speed on one wheel
			motorAdjust = (10)*distance - 200; 			//function for proportional control
			leftMotor.setSpeed(motorStraight);			// if distance < 40, speed decreases below 200. 
			rightMotor.setSpeed(motorAdjust);			// if distance > 40, speed increases above 200. 
			leftMotor.forward();
			rightMotor.forward();
		}
		
		else if (distance <= 30) {							// if too close to wall (under 30cm), reverse right wheel
			leftMotor.setSpeed(motorStraight);					
			rightMotor.setSpeed(-400 - (1/20)*distance);	//linear function for reverse speed
			leftMotor.forward();
			rightMotor.backward();
		}
		
	}

	
	@Override
	public int readUSDistance() {
		return this.distance;
	}

}
