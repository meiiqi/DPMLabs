package BallLauncher;

import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.lcd.TextLCD; 


/*
 * This class implements a ball launcher mechanism that can pitch a ball from approximately 90 cm away from target, 
 * bounce once in between, and then hit the target at one of the 3 possible positions: left, center, or right. 
 */
public class Lab5 {
	
	private static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));
	private static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));
	private static final EV3LargeRegulatedMotor catapultMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("B"));
	public static final double WHEEL_RADIUS = 2.15, TRACK=16.2;
	public static final int ROTATE_SPEED=200, THROW_SPEED=1700, READY_ANGLE=65, LAUNCH_ANGLE=120;

	public static void main(String [] args) {
		//initializations
		Odometer odo = new Odometer(leftMotor, rightMotor);
		odo.start();  //odometer keeps track of current heading 
		
		catapultMotor.setSpeed(THROW_SPEED);   //sets arm speed to a constant found experimentally, 
											   //for the project this would be a function depending of y distance, instead of a constant.
		catapultMotor.rotate(-READY_ANGLE);   //puts arm in position to load ball, assumes arm is in lowest possible position at start
		
		int buttonChoice;      //records which button is pressed
		
		double dTheta=(Math.atan2(1, 3)*180/Math.PI);   //angle difference between left/right targets from center target
		
		final TextLCD t = LocalEV3.get().getTextLCD();  //draw choices on display
		t.clear();
		t.drawString("up", 7,0);
		t.drawString("middle target", 2,1);
		t.drawString("left", 1,3);
		t.drawString("target", 0,4);
		t.drawString("right", 12,3);
		t.drawString("target", 11,4);
		t.drawString("Press Enter", 3, 6);
		t.drawString("to Fire", 4, 7);
		
		
		/*
		 * This is the ball launching mechanism depending on the target selected. 
		 * A button press launches the ball.
		 * This ball launcher will keep going until the exit button is pressed.
		 */
		while (true){  
			
			buttonChoice=Button.waitForAnyPress(); //wait for target to be selected
			
			if (buttonChoice==Button.ID_LEFT){          //left target selected 
				turnTo(-dTheta, odo);
				}
			
			else if (buttonChoice==Button.ID_RIGHT){    //right target selected
				turnTo(dTheta, odo);
				}
			
			else if (buttonChoice==Button.ID_UP){       //center target selected
				turnTo(0, odo);
				}
			
			else if (buttonChoice==Button.ID_ENTER){    //fires ball and then returns arm to its ready position
				catapultMotor.rotate(-LAUNCH_ANGLE); //rotates quickly until desired launch angle is achieved then stops abruptly to launch ball 
				catapultMotor.rotate(LAUNCH_ANGLE);  //resets arm to its ready position
			}
			
			else if(buttonChoice==Button.ID_ESCAPE){    //exits program and returns arm to starting position
				catapultMotor.setSpeed(ROTATE_SPEED);
				catapultMotor.rotate(READY_ANGLE); 
				System.exit(0);
				}
			}
		}
	
	//This method converts a certain distance to number to radians the wheels should turn
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	//This method converts the angle of orientation of the robot from degrees to number of radians wheels should rotate
	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	
	//This method rotates the robot to a specific point
	static void turnTo (double dTheta, Odometer odo){
			
			double rTheta = odo.getTheta();	//record current heading
			double error = dTheta - rTheta;		//error is amount of angle desired to turn
			
				//calculate minimum angle for turns
				if (error < -180){
					error += 360;
				}
				else if (error > 180) {
					error -=360;
				}
				
				//set speeds and execute turn 
				leftMotor.setSpeed(ROTATE_SPEED);
				rightMotor.setSpeed(ROTATE_SPEED);
		
				leftMotor.rotate(convertAngle(WHEEL_RADIUS, TRACK, error), true);
				rightMotor.rotate(-convertAngle(WHEEL_RADIUS, TRACK, error), false);
				
		}
}

