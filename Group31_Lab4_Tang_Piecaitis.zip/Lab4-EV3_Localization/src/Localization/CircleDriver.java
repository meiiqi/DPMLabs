package Localization;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

/*
 * This class performs the circling around the center of rotation of robot (between it's wheels)
 * in order to localize it's current position with a color sensor that detects black lines.
 */
public class CircleDriver extends Thread{
	//initializations
	private Navigation nav;
	public boolean circling;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	private LightLocalizer lsl;
	
	//Constructor
	public CircleDriver(Navigation nav, EV3LargeRegulatedMotor leftMotor,EV3LargeRegulatedMotor rightMotor, LightLocalizer lsl){
		this.nav=nav;
		this.leftMotor=leftMotor;
		this.rightMotor=rightMotor;
		this.lsl=lsl;
	}
	
	
	public void run() {
		//set rotating speed
		leftMotor.setSpeed(30);
		rightMotor.setSpeed(30);
		
		
		nav.rotate(45); 	//turn 45 degrees to turn towards tile's right corner
		nav.forward(200); 	//travel to corner (sets distance big enough ans wait for interruption)
		
		//will get interrupted by sensing black line
		
		nav.backward(15); 	//After interruption, return back to tile, prepare circling
		
		nav.rotate(360); 	//circle around center of rotation
		lsl.setCircling(false); //update circling state after circling is finished
		
	}
}

