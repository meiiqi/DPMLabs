package Localization;

import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.robotics.SampleProvider;

/*
 * This localization class uses the ultrasonic sensor to detect walls and correct robot's initial heading
 * to be facing positive y-axis (theta= 0 degree).
 * It implements two ways to detecting the walls: falling edge and rising edge.
 * Since rising edge is more accurate, we dont use falling edge.
 */
public class USLocalizer {
	//initialize variables
	public enum LocalizationType { FALLING_EDGE, RISING_EDGE };
	public static double ROTATION_SPEED = 30;
	public static final double WHEEL_RADIUS = 2.15;
	public static final double TRACK = 16.2; 
	private static final int ROTATE_SPEED = 30;
	private double currentDist=0, lastDist=0; //distances detected by usSensor

	//create local instances
	private Odometer odo;
	private Navigation nav;
	private SampleProvider usSensor;
	private float[] usData;
	private LocalizationType locType;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	
	public USLocalizer(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, Odometer odo, Navigation nav,  SampleProvider usSensor, float[] usData, LocalizationType locType) {
		this.odo = odo;
		this.nav = nav;
		this.usSensor = usSensor;
		this.usData = usData;
		this.locType = locType;
		this.leftMotor=leftMotor;
		this.rightMotor=rightMotor;
	}
	
	/*
	 * This method does the localization. 
	 * Both implementations of falling edge and rising edge are in here.
	 * There is a filter system to improve accuracy.
	 */
	public void doLocalization() {
		double angleA, angleB;
		
		//set rotational wheel speed
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		
		
		//Falling edge implementation
		if (locType == LocalizationType.FALLING_EDGE) {
			
			//Graph data for a full 360, to evaluate noise and set up a margin for filter
//			for(int i =0; i< 72; i++ ){
//			getFilteredData();
//			rotate(5);
//			}
			
			
			while(getFilteredData()<50){ // rotate the robot until it sees no wall
				nav.rotate(5);			//rotation split into chunks of 5 degrees
			}
			
			while(!(fallingEdge())){ 	// keep rotating until the robot sees a wall, then latch the angle
				nav.rotate(5);
			}
			//angle A is the average angle between the previous theta and the current theta
			//angleA = (odo.getTheta()+(odo.getTheta()-5))/2 
			angleA =(odo.getTheta() - 2.5); //(simplified equation)
			
			
			while(getFilteredData()<50){ // switch direction and wait until it sees no wall
				nav.rotate(-5);
			}
			
			while(!(fallingEdge())){	// keep rotating until the robot sees a wall, then latch the angle
				nav.rotate(-5);
			}
			
			//angleB is the average angle between the previous theta and the current theta
			angleB =(odo.getTheta()+2.5); //+2.5 because theta decreases over time (going in other direction)

			//Calculate initial heading of robot
			double initHeading = calculate(angleA, angleB);
			
			//st correct heading
			odo.setTheta(angleB+initHeading);
			//turn to 0degree heading  (positive y-axis)
			nav.turnTo (0, leftMotor,  rightMotor, WHEEL_RADIUS,  WHEEL_RADIUS,  TRACK);
			
		} 
		
		//Rising edge implementation
		else {
			
			while(getFilteredData()>50){ //robot should turn until it sees the wall
				nav.rotate(5);
			}
			while(!(risingEdge())){ 	// keep rotating until the robot sees no wall, then latch the angle
				nav.rotate(5);
			}
			
			angleB =(odo.getTheta()-2.5);
			
			while(getFilteredData()>50){ // switch direction and wait until it sees no wall
				nav.rotate(-5);
			}
			
			while(!(risingEdge())){// keep rotating until the robot sees a wall, then latch the angle
				nav.rotate(-5);
			}
			
			angleA =(odo.getTheta() + 2.5); 
		
			//calculate initial heading
			double initHeading = calculate(angleA, angleB);
			//set to correct current heading
			odo.setTheta(angleA+initHeading);
			//turn to 0 degree positive y-axis
			nav.turnTo (0, leftMotor,  rightMotor, WHEEL_RADIUS,  WHEEL_RADIUS,  TRACK);
		}
	}
	
	/*
	 * This method detects a falling edge, which is when the distance that USsensor senses decreases
	 */
	public boolean fallingEdge (){
		//if the decrease of distance (going from not sensing a wall to sensing a wall) 
		//falls more than 40cm, there's a falling edge.
		if(lastDist - getFilteredData() > 40){
			return true;
		}
		else return false;
	}
	
	/*
	 * This method detects a rising edge, which is when the distance increases
	 */
	public boolean risingEdge (){
		//If there is an increase in distance of more than 40cm, there is a rising edge
		if(getFilteredData() - lastDist > 40){
			return true;
		}
		else return false;
	}
	
	
	/*
	 * This method calculates the initial heading of the robot relative to the positive y-axis (0 degree)
	 */
	private double calculate(double angleA, double angleB){               
	
		if (angleA>angleB){
			return (45-((angleA+angleB))/2);
		}
		else{
			return (225-((angleA+angleB))/2);
		}

	}
	
	/*
	 * This method gets the filtered data from the sensor.
	 * it changes all infinity values (when not sensing anything) to 100
	 */
	public double getFilteredData() {
		//if first time getting data
		if (lastDist == 0 && currentDist == 0){ 
			
			usSensor.fetchSample(usData, 0);	//fetch data
			double distance = (double)(usData[0]*100.0);	//cast to cm
			
			if (distance>=100){ //if not sensing anything
				distance = 100;
			}
			
			//initialize both distances to be the same 
			//(instead of being 0 and then having a change of > 40cm as soon as the next data gets registered
			lastDist = distance;
			currentDist = distance;
		}
		
		else {
			
			lastDist = currentDist;    					 //update last distance
			
			usSensor.fetchSample(usData, 0);   				//fetch new distance
			
			double distance = (double)(usData[0]*100.0);      //cast distance to cm
			
			if (distance>=100){ 		//if not sensing anything
				distance = 100;
			}
			
			currentDist = distance;		//update current distance
			
		//	System.out.println(currentDist); just to print out to graph data
		}
		
		return currentDist;
	}

}
