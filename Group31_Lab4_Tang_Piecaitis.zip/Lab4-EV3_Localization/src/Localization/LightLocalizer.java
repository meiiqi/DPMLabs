package Localization;

import lejos.hardware.Sound;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.robotics.SampleProvider;

/*
 * This class localizes the robot's initial position and navigates to the origin with 0 degrees heading.
 * Data is fetched by a color sensor located at the back of the robot, at a distance of 13.7cm from the center of rotation (center of wheels)
 * This class calls a CircleDriver thread to perform a 360 rotation close to the top right corner of the first tile in order to perform localization.
 */
public class LightLocalizer {
	//initializations
	private Odometer odo;
	private SampleProvider colorValue;
	private float[] colorData;
	private Navigation nav;
	public static final double light_Dist= 13.7; //distance between light sensor and center of rotation (cm)
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	public static final double WHEEL_RADIUS = 2.15;
	public static final double TRACK = 16.2; 
	public boolean circling;


	public LightLocalizer(Odometer odo, SampleProvider colorValue, float[] colorData, Navigation nav, EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor) {
		this.odo = odo;
		this.colorValue = colorValue;
		this.colorData = colorData;
		this.nav=nav;
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
	}
	
	/*
	 * This method localizes its position, then travels to position (0,0) with heading towards 0 degree y-axis
	 */
	public void doLocalization() {
		//initializations
		double angle1=0.0, angle2=0.0, angle3=0.0, angle4 = 0.0, Ty=0.0, Tx=0.0, rx=0.0, ry=0.0;
		circling=true; 
		int i=0;
		
		//start circling to localize position of center of rotation
		CircleDriver cd=new CircleDriver(nav, leftMotor, rightMotor, this);
		cd.start();
		
		//when circling, fetch sensor data and record angles when passing a black line
		while(isCircling()==true){
			
			colorValue.fetchSample(colorData, 0);  //collect data
			
			if((colorData[0]==13)){    //if sensing a black line
				
				switch(i){	
				//it's expected to sense 4 black lines. 
				//However, if it senses the corner as two black lines, go to case 5 and shift all angle values
				
					case 0: {	 //tile corner
						rightMotor.stop(true);
						leftMotor.stop(true);
					}
					case 1: {angle1=odo.getTheta(); i++; Sound.buzz(); break;} 	//x- line
					case 2: {angle2=odo.getTheta(); i++; Sound.buzz(); break;} 	//y+ line
					case 3: {angle3=odo.getTheta(); i++; Sound.buzz(); break;} 	//x+ line
					case 4: {angle4=odo.getTheta(); i++; Sound.buzz(); break;} 	//y- line
					
					//if sensed tile corner twice, shift all the angle values => discard first one
					case 5: {angle1=angle2; angle2=angle3; angle3=angle4; angle4=odo.getTheta(); Sound.buzz(); break;}
				}
			}
		}
		
		
		Ty=angle4-angle2;  // Ty is Theta y
		Tx=angle3-angle1;	//Tx is Theta x
		
		ry=-light_Dist*Math.cos((Tx/360)*Math.PI);	//rx is x component of position 
		rx=-light_Dist*Math.cos((Ty/360)*Math.PI);	//ry is y component of position
		
		//set to correct current position
		odo.setX(rx);
		odo.setY(ry);
		
		
		
		odo.setTheta((odo.getTheta())%360); //set odometer theta to correct current heading
		
		//After correcting position, travel to origin and turn towards 0 degree heading
		nav.travelTo (0,0); 
		nav.turnTo(0, leftMotor,  rightMotor, WHEEL_RADIUS,  WHEEL_RADIUS,  TRACK);
		
	}
	
	
	//This method returns whether robot is circling in order to localize itself
	public boolean isCircling(){
		return circling;
	}
	
	//This method sets robot's circling state
	public void setCircling(boolean x){
		circling=x;
	}
}
